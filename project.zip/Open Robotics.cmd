@echo off
docker start afb5f5d541bf >nul
if errorlevel 1 (
  echo Start Docker Desktop, then try this launcher again.
  pause
  exit /b 1
)
call "C:\Users\janhu\AppData\Local\Programs\Microsoft VS Code\bin\code.cmd" --new-window --folder-uri "vscode-remote://attached-container+7b22636f6e7461696e65724e616d65223a222f736572656e655f776f7a6e69616b227d/workspaces/Robtics"
